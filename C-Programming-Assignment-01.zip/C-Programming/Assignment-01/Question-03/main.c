#include <stdio.h>

int main() {
    int coins, x, y, ben, blackbeard, remaining, each;

    scanf("%d%d%d", &coins, &x, &y);

    ben = coins * x / 100;
    remaining = coins - ben;

    blackbeard = remaining * y / 100;
    remaining = remaining - blackbeard;

    each = remaining / 3;

    printf("%d\n", ben);
    printf("%d\n", blackbeard);
    printf("%d", each);

    return 0;
}
