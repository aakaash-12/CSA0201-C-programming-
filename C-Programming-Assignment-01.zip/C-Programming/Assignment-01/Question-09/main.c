#include <stdio.h>

int main() {
    int year, month, days;

    scanf("%d%d", &year, &month);

    if (year < 1900 || year > 9999 || month < 1 || month > 12) {
        printf("0");
    }
    else if (month == 2) {
        if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
            days = 29;
        else
            days = 28;

        printf("%d Days", days);
    }
    else if (month == 4 || month == 6 || month == 9 || month == 11) {
        printf("30 Days");
    }
    else {
        printf("31 Days");
    }

    return 0;
}
