# C Programming - Assignment 01

Name: G R AAKAASH

Register Number: Your Register Number

SLOT: B
