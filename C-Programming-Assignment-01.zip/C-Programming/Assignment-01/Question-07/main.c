#include <stdio.h>

int main() {
    float x, r, y, interest, amount, discount, final;

    scanf("%f%f%f", &x, &r, &y);

    interest = x * r * y / 100;
    amount = x + interest;
    discount = interest * 2 / 100;
    final = amount - discount;

    printf("%.2f\n", interest);
    printf("%.2f\n", amount);
    printf("%.2f\n", discount);
    printf("%.2f", final);

    return 0;
}
